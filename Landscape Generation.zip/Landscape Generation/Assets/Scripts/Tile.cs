﻿using UnityEngine;
using System.Collections;

public class Tile{
	[HideInInspector]
	public GameObject tile = new GameObject ("Tile");
	private SpriteRenderer sr;
	public Sprite[] spriteArray;

	public int type;

	public Tile(int type, /*params*/ Sprite[] sprites){
		spriteArray = sprites;
		this.type = type;
		sr = tile.AddComponent (typeof(SpriteRenderer)) as SpriteRenderer;
		SetTileType (this.type);
	}

	void SetTileType(int type){
		if (type == 0) {
			sr.sprite = spriteArray[0];
		}else if(type == 1){
			sr.sprite = spriteArray [1];
		}
	}
}
