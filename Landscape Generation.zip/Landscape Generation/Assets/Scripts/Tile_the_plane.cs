﻿using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;

public class Tile_the_plane : MonoBehaviour {

	public int columns = 8;
	public int rows = 8;

	public GameObject Tile;

	private Transform planeHolder;
	private List<Vector3> coordinates = new List<Vector3> ();

	void InitialiseList(){
		coordinates.Clear ();

		for(int x = 0; x < columns; x++){
			for (int y = 0; y < rows; y++) {
				coordinates.Add (new Vector3 (x, y, 0.0f));
			}
		}
	}

	void PlaneSetUp(){
		planeHolder = new GameObject ("Plane").transform;

		for (int x = 0; x < columns; x++) {
			for (int y = 0; y < rows; y++) {
				GameObject toInstantiate = Tile;
				GameObject instance = Instantiate (toInstantiate, new Vector3 (x, y, 0f), Quaternion.identity) as GameObject;
				instance.transform.SetParent (planeHolder);
			}
		}
	}

	public void SetUpPlane(){
		InitialiseList ();
		PlaneSetUp ();
	}

}
