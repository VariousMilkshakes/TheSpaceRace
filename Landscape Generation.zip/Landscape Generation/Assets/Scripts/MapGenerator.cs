﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class MapGenerator : MonoBehaviour {

	public int columns;
	public int rows;

	public string seed;
	public bool randomSeed;

	[Range(0,100)]
	public int waterPercentage;

	public Tile tile;
	public Sprite[] sprites;
	//public GameObject Tile;
	private Transform mapHolder;

	int[,] gridPos;

	void Start(){
		GenerateMap ();
		SetUpMap ();
	}

	void Update(){
		if (Input.GetMouseButtonDown (0)) {
			Smooth ();
		}
	}

	void GenerateMap(){
		gridPos = new int[columns, rows];
		RandomiseGrid ();
		for (int i = 0; i < 5; i++) {
			Smooth ();
		}

		ProcessGrid ();
	}

	void ProcessGrid(){
		List<List<Coord>> waterRegions = GetRegions (1);
		int waterThresholdSize = 20;

		foreach (List<Coord> waterRegion in waterRegions) {
			if(waterRegion.Count < waterThresholdSize){
				foreach (Coord tile in waterRegion){
					gridPos [tile.tileX, tile.tileY] = 0;
				}
			}
		}

		List<List<Coord>> grassRegions = GetRegions (0);
		int grassThresholdSize = 20;

		foreach (List<Coord> grassRegion in grassRegions) {
			if(grassRegion.Count < grassThresholdSize){
				foreach(Coord tile in grassRegion){
					gridPos [tile.tileX, tile.tileY] = 1;
				}
			}
		}
	}

	List<List<Coord>> GetRegions(int tileType){
		List<List<Coord>> regions = new List<List<Coord>> ();
		int[,] gridFlags = new int[columns, rows];

		for (int x = 0; x < columns; x++){
			for (int y = 0; y < rows; y++){
				if (gridFlags [x, y] == 0 && gridPos [x, y] == tileType) {
					List<Coord> newRegion = GetRegionTiles (x, y);
					regions.Add (newRegion);

					foreach (Coord tile in newRegion) {
						gridFlags [tile.tileX, tile.tileY] = 1;
					}
				}
			}
		}
		return regions;
	}

	List<Coord> GetRegionTiles(int startX, int startY){
		List<Coord> tiles = new List<Coord>(); 
		int[,] gridFlags = new int[columns, rows];
		int tileType = gridPos [startX, startY];

		Queue<Coord> queue = new Queue<Coord> ();
		queue.Enqueue (new Coord(startX, startY));
		gridFlags [startX, startY] = 1;

		while (queue.Count > 0) {
			Coord tile = queue.Dequeue ();
			tiles.Add (tile);
			for (int x = tile.tileX - 1; x <= tile.tileX + 1; x++) {
				for (int y = tile.tileY - 1; y <= tile.tileY + 1; y++) {
					if(IsInRange(x,y) && (y == tile.tileY || x == tile.tileX)){
						if(gridFlags[x,y] == 0 && gridPos[x,y] == tileType){
							gridFlags [x, y] = 1;
							queue.Enqueue (new Coord (x, y));
						}
					}
				}
			}
		}
		return tiles;
	}

	bool IsInRange(int x, int y){
		return x >= 0 && x < columns && y >= 0 && y < rows;
	}

	/*This method Randomises all of the values in gridPos to be either 0 (a grass tile) or 1 (a water tile).
	 *This is achieved by iterating over each element in the array and using Random.Next with a range of 0 - 100 and comparing the value with the waterPercentage int.
	*/
	void RandomiseGrid(){
		if(randomSeed){
			seed = Random.Range (-1000f, 1000f).ToString ();
		}
		System.Random rnd = new System.Random (seed.GetHashCode ());

		for (int x = 0; x < columns; x++) {
			for (int y = 0; y < rows; y++) {
				gridPos [x, y] = (rnd.Next (0, 100) < waterPercentage) ? 1 : 0;
			}
		}
	}

	void Smooth(){
		for (int x = 0; x < columns; x++) {
			for (int y = 0; y < rows; y++) {
				int adjacentTiles = GetAdjacentWaterCount (x, y);
				if (adjacentTiles > 4){
					gridPos [x, y] = 1;
				}else if (adjacentTiles < 4){
					gridPos [x, y] = 0;
				}
			}
		}
	}

	int GetAdjacentWaterCount(int posX, int posY){
		int adjacentTiles = 0;
		for (int adjX = posX -1; adjX <= posX +1; adjX++) {
			for (int adjY = posY -1; adjY <= posY +1; adjY++) {
				if(adjX >= 0 && adjX < columns && adjY >= 0 && adjY < rows){
					if (adjX != posX || adjY != posY) {
						adjacentTiles += gridPos [adjX, adjY];
					}
				}
			}
		}
		return adjacentTiles;
	}

	void SetUpMap(){
		mapHolder = new GameObject ("Map").transform;

		if (gridPos != null) {
			for(int x = 0; x < columns; x++){
				for (int y = 0; y < rows; y++){
					tile = new Tile (gridPos [x, y], sprites);
					GameObject toInstantiate = tile.tile;
					GameObject instance = Instantiate (toInstantiate, new Vector3 (x, y, 0f), Quaternion.identity) as GameObject;
					instance.transform.SetParent (mapHolder);
				}
			}
		}
	}

	struct Coord{
		public int tileX;
		public int tileY;

		public Coord (int x, int y){
			tileX = x;
			tileY = y;
		}
	}
}
