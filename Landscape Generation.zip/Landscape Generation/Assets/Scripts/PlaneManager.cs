﻿using UnityEngine;
using System.Collections;

public class PlaneManager : MonoBehaviour {

	public Tile_the_plane planeScript;

	void Awake() {
		planeScript = GetComponent<Tile_the_plane> ();
		InitPlane ();
	}

	void InitPlane(){
		planeScript.SetUpPlane ();
	}
}
