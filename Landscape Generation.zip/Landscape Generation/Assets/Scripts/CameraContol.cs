﻿using UnityEngine;
using System.Collections;

public class CameraContol : MonoBehaviour {

	public Camera camera;
	public float speed;
	public Rigidbody2D rb;
	public float zoomMin;
	public float zoomMax;
	public float scrollMult;
	public float xMoveMin;
	public float xMoveMax;
	public float yMoveMin;
	public float yMoveMax;
	private float zoomSpeed;


	// Use this for initialization
	void Start () {
		rb = camera.GetComponent<Rigidbody2D> ();
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	void Zoom(){
		float scroll = Input.GetAxis ("Mouse ScrollWheel");
		if (camera.orthographicSize > zoomMax) {
			camera.orthographicSize = zoomMax;
		} else if (camera.orthographicSize < zoomMin) {
			camera.orthographicSize = zoomMin;
		} else {
			camera.orthographicSize = Mathf.SmoothDamp (camera.orthographicSize, camera.orthographicSize + scroll * scrollMult, ref zoomSpeed, 0.2f);
		}

	}

	void Move(){
		float moveHorizontal = Input.GetAxis ("Horizontal");
		float moveVertical = Input.GetAxis ("Vertical");

		Vector3 movement = new Vector3 (moveHorizontal, moveVertical, 0.0f);
		rb.velocity = movement * speed;

		rb.position = new Vector3 (Mathf.Clamp (rb.position.x, xMoveMin, xMoveMax), Mathf.Clamp (rb.position.y, yMoveMin, yMoveMax), 0.0f);

		rb.rotation = 0.0f;
	}

	void FixedUpdate(){
		Zoom ();
		Move ();
	}
}
