﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum TileTypes{

	GRASS, 
	WATER, 
	SAND, 
	MOUNTAIN
}
