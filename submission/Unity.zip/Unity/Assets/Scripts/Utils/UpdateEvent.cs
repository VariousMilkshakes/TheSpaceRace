﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine.Events;

namespace SpaceRace.Utils
{
	public class UpdateEvent : UnityEvent<int, object[]>
	{
	}
}
