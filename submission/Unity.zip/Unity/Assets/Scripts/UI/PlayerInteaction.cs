﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;


public class PlayerInteaction : MonoBehaviour {

	//public void newgameBtn (string newGame){
	//	SceneManager.LoadScene(newGame)
	//}

	//public void quitBtn (string quitgame){
		
	//}
}
