﻿
public class GameOptions 
{  //class that is blueprint of the options
    public int mapHeight;
    public int mapWidth;
    public string worldSeed;
    public float waterCoverage;
    public bool close;
    public bool back;
    public bool startGame;
    public bool multiPlayer;
    public string numberOfPlayers;
    public string userID;
    //public bool back;
    
    

   // public MapGenerator mapGenerator;
    //public GameOptions gameOptions;







}
